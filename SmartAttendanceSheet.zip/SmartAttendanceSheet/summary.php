<?php
require_once("config.php");

# If session is not active, start the session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

# If the user is not logged in, redirect them to the login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== TRUE) {
    echo "<script>" . "window.location.href='./login.php';" . "</script>";
    exit;
}

$username = $_SESSION["username"];

# Fetch the institution of the logged-in user from the "users" table
$institutionQuery = "SELECT institution FROM users WHERE username = '$username'";
$institutionResult = mysqli_query($db, $institutionQuery);

if ($institutionResult && mysqli_num_rows($institutionResult) > 0) {
    $institutionData = mysqli_fetch_assoc($institutionResult);
    $userInstitution = $institutionData['institution'];
} else {
    // Handle the case where the institution is not found
    $userInstitution = "";
}

$isAdmin = ($userInstitution === "admin");

$firstDayOfMonth = date("1-m-Y");
$selectedStartDate = isset($_POST['selected_start_date']) ? $_POST['selected_start_date'] : date('Y-m-d');
$selectedEndDate = isset($_POST['selected_end_date']) ? $_POST['selected_end_date'] : date('Y-m-d');
$totalDaysInRange = floor((strtotime($selectedEndDate) - strtotime($selectedStartDate)) / (60 * 60 * 24)) + 1;

// Fetching Students 
if ($isAdmin) {
    $fetchingStudents = mysqli_query($db, "SELECT * FROM attendance_students") OR die(mysqli_error($db));
} else {
    $fetchingStudents = mysqli_query($db, "SELECT * FROM attendance_students WHERE institution = '$userInstitution'") OR die(mysqli_error($db));
}

// Initialize an array to store students segregated by institution
$studentsByInstitution = array();

while ($students = mysqli_fetch_assoc($fetchingStudents)) {
    $institution = $students['institution'];
    $studentsByInstitution[$institution][] = array(
        'id' => $students['id'],
        'student_name' => $students['student_name']
    );
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Summary</title>
    <!-- Add the Bootstrap CDN link here -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }

        .container {
            margin-top: 20px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

        td {
            background-color: #ffffff;
        }

        .present {
            background-color: #28a745;
            color: white;
        }

        .absent {
            background-color: #dc3545;
            color: white;
        }

        .holiday {
            background-color: #007bff;
            color: white;
        }

        .leave {
            background-color: #8B4513;
            color: white;
        }

        form {
            margin-bottom: 20px;
        }

        select,
        input[type="date"],
        input[type="submit"] {
            margin-right: 10px;
        }

        .bar {
            display: inline-block;
            width: 20px;
            margin-right: 5px;
        }
    </style>
</head>

<body>
    <div class="container">
        <form method="POST">
            <label for="selected_start_date">Start Date:</label>
            <input type="date" name="selected_start_date" id="selected_start_date" value="<?= $selectedStartDate ?>" class="form-control">

            <label for="selected_end_date">End Date:</label>
            <input type="date" name="selected_end_date" id="selected_end_date" value="<?= $selectedEndDate ?>" class="form-control">
            <br>
            <center>
                <input type="submit" value="Show Summary" class="btn btn-primary">
                <a href="./index.php" class="btn btn-secondary mx-2">Back</a>
            </center>
        </form>

        <?php
        // Display summary table for each institution
        foreach ($studentsByInstitution as $institution => $students) {
            echo "<h2>Attendance Summary for Institution: $institution</h2>";
        ?>
            <table class="table table-bordered">
                <tr>
                    <th>Names</th>
                    <th>Total Working Days</th>
                    <th>Total Present Days</th>
                    <th>Total Absents</th>
                    <th>Total Leaves</th>
                    <th>Total Holidays</th>
                    <th>% of Attendance</th>
                </tr>
                <?php
                foreach ($students as $student) {
                    $studentID = $student['id'];
                    $studentName = $student['student_name'];

                    // Fetch attendance summary for each student
                    $fetchingAttendanceSummary = mysqli_query($db, "SELECT attendance FROM attendance WHERE student_id = '$studentID' AND curr_date BETWEEN '$selectedStartDate' AND '$selectedEndDate'") OR die(mysqli_error($db));

                    $totalWorkingDays = 0;
                    $totalPresentDays = 0;
                    $totalAbsents = 0;
                    $totalLeaves = 0;
                    $totalHolidays = 0;

                    while ($attendanceData = mysqli_fetch_assoc($fetchingAttendanceSummary)) {
                        $totalWorkingDays++;

                        switch ($attendanceData['attendance']) {
                            case 'P':
                                $totalPresentDays++;
                                break;
                            case 'A':
                                $totalAbsents++;
                                break;
                            case 'L':
                                $totalLeaves++;
                                break;
                            case 'H':
                                $totalHolidays++;
                                break;
                        }
                    }

                    echo "<tr>";
                    echo "<td>" . $studentName . "</td>";
                    echo "<td>{$totalWorkingDays}</td>";
                    echo "<td>{$totalPresentDays}</td>";
                    echo "<td>{$totalAbsents}</td>";
                    echo "<td>{$totalLeaves}</td>";
                    echo "<td>{$totalHolidays}</td>";
                    echo "<td>";
                    if ($totalWorkingDays > 0) {
                        $attendancePercentage = ($totalPresentDays / $totalWorkingDays) * 100;
                        echo number_format($attendancePercentage, 2) . '%';
                        echo "<div class='progress' style='height: 20px;'>";
                        echo "<div class='progress-bar bg-success' role='progressbar' style='width: $attendancePercentage%' aria-valuenow='$attendancePercentage' aria-valuemin='0' aria-valuemax='100'></div>";
                        echo "</div>";
                    } else {
                        // Handle the case where totalWorkingDays is zero (to avoid division by zero)
                        echo "N/A";
                    }
                    echo "</td>";
                    echo "</tr>";
                }
                ?>
            </table>
        <?php
        }
        ?>

    </div>

    <!-- Add the Bootstrap JS and Popper.js scripts here -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-U8aR+k8lJKJe2vnDZsSgoK03tb3FzA+V6X5Ag9+rmrDXtjUqamo6rAGiG+tpO73I" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>
