<?php
require_once("config.php");

# If session is not active, start the session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

# If user is not logged in then redirect him to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== TRUE) {
    echo "<script>" . "window.location.href='./login.php';" . "</script>";
    exit;
}

$username = $_SESSION["username"];

# Fetch the institution of the logged-in user from the "users" table
$institutionQuery = "SELECT institution FROM users WHERE username = '$username'";
$institutionResult = mysqli_query($db, $institutionQuery);

if ($institutionResult && mysqli_num_rows($institutionResult) > 0) {
    $institutionData = mysqli_fetch_assoc($institutionResult);
    $userInstitution = $institutionData['institution'];
} else {
    // Handle the case where the institution is not found
    $userInstitution = "";
}

$firstDayOfMonth = date("1-m-Y");
$selectedMonth = isset($_POST['selected_month']) ? $_POST['selected_month'] : date('m');
$selectedYear = isset($_POST['selected_year']) ? $_POST['selected_year'] : date('Y');
$selectedDate = $selectedYear . '-' . $selectedMonth . '-01';
$totalDaysInMonth = date("t", strtotime($selectedDate));

// If the logged-in user is an admin, allow them to view attendance for all institutions
if ($userInstitution === "admin") {
    $fetchingStudents = mysqli_query($db, "SELECT * FROM attendance_students") OR die(mysqli_error($db));
} else {
    // Fetching Students based on the institution of the logged-in user
    $fetchingStudents = mysqli_query($db, "SELECT * FROM attendance_students WHERE institution = '$userInstitution'") OR die(mysqli_error($db));
}

// Initialize an array to store students segregated by institution
$studentsByInstitution = array();

while ($students = mysqli_fetch_assoc($fetchingStudents)) {
    $institution = $students['institution'];
    $studentsByInstitution[$institution][] = array(
        'id' => $students['id'],
        'student_name' => $students['student_name']
    );
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Table</title>
    <!-- Add the Bootstrap CDN link here -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }

        .container {
            margin-top: 20px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

        td {
            background-color: #ffffff;
        }

        .present {
            background-color: #28a745;
            color: white;
        }

        .absent {
            background-color: #dc3545;
            color: white;
        }

        .holiday {
            background-color: #007bff;
            color: white;
        }

        .leave {
            background-color: #8B4513;
            color: white;
        }

        form {
            margin-bottom: 20px;
        }

        select,
        input[type="submit"] {
            margin-right: 10px;
        }
    </style>
</head>

<body>
    <div class="container">
        <form method="POST">
            <label for="selected_month">Select Month:</label>
            <select name="selected_month" id="selected_month" class="form-control">
                <?php
                for ($month = 1; $month <= 12; $month++) {
                    $monthName = date('F', mktime(0, 0, 0, $month, 1, 2000));
                    $selected = ($selectedMonth == $month) ? 'selected' : '';
                    echo "<option value=\"$month\" $selected>$monthName</option>";
                }
                ?>
            </select>

            <label for="selected_year">Select Year:</label>
            <select name="selected_year" id="selected_year" class="form-control">
                <?php
                $currentYear = date('Y');
                for ($year = $currentYear - 5; $year <= $currentYear + 5; $year++) {
                    $selected = ($selectedYear == $year) ? 'selected' : '';
                    echo "<option value=\"$year\" $selected>$year</option>";
                }
                ?>
            </select>
            <br>
            <center>
                <input type="submit" value="Show Attendance" class="btn btn-primary">
                <a href="./index.php" class="btn btn-secondary mx-2">Back</a>
            </center>
        </form>

        <?php
        // Display attendance table for each institution
        foreach ($studentsByInstitution as $institution => $students) {
            echo "<h2>Attendance Table for Institution: $institution</h2>";
        ?>
            <table class="table table-bordered">
                <?php
                for ($i = 1; $i <= count($students) + 2; $i++) {
                    if ($i == 1) {
                        echo "<tr>";
                        echo "<th rowspan='2'>Names</th>";
                        for ($j = 1; $j <= $totalDaysInMonth; $j++) {
                            echo "<th>$j</th>";
                        }
                        echo "</tr>";
                    } else if ($i == 2) {
                        echo "<tr>";
                        for ($j = 0; $j < $totalDaysInMonth; $j++) {
                            echo "<th>" . date("D", strtotime("+$j days", strtotime($selectedDate))) . "</th>";
                        }
                        echo "</tr>";
                    } else {
                        echo "<tr>";
                        echo "<td>" . $students[$i - 3]['student_name'] . "</td>";
                        for ($j = 1; $j <= $totalDaysInMonth; $j++) {
                            $dateOfAttendance = date("Y-m-$j", strtotime($selectedDate));
                            $fetchingStudentsAttendance = mysqli_query($db, "SELECT attendance FROM attendance WHERE student_id = '" . $students[$i - 3]['id'] . "' AND curr_date = '" . $dateOfAttendance . "'") OR die(mysqli_error($db));

                            $isAttendanceAdded = mysqli_num_rows($fetchingStudentsAttendance);
                            if ($isAttendanceAdded > 0) {
                                $studentAttendance = mysqli_fetch_assoc($fetchingStudentsAttendance);
                                $colorClass = '';

                                switch ($studentAttendance['attendance']) {
                                    case 'P':
                                        $colorClass = 'present';
                                        break;
                                    case 'A':
                                        $colorClass = 'absent';
                                        break;
                                    case 'H':
                                        $colorClass = 'holiday';
                                        break;
                                    case 'L':
                                        $colorClass = 'leave';
                                        break;
                                    default:
                                        $colorClass = '';
                                        break;
                                }

                                echo "<td class='$colorClass'>" . $studentAttendance['attendance'] . "</td>";
                            } else {
                                echo "<td></td>";
                            }
                        }
                        echo "</tr>";
                    }
                }
                ?>
            </table>
        <?php
        }
        ?>

    </div>

    <!-- Add the Bootstrap JS and Popper.js scripts here -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-U8aR+k8lJKJe2vnDZsSgoK03tb3FzA+V6X5Ag9+rmrDXtjUqamo6rAGiG+tpO73I" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>
