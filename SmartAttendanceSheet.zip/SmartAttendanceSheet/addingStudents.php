<form method="POST">
    <input type="text" name="student_name" placeholder="Student Name" required autofocus />
    <input type="text" name="institution_name" placeholder="Institution Name" required />
    <input type="submit" value="Add Student" name="submit">
</form>
<?php
if (isset($_POST['submit'])) {
    require_once("config.php");

    // Sanitize inputs to prevent SQL injection
    $student_name = mysqli_real_escape_string($db, $_POST['student_name']);
    $institution_name = isset($_POST['institution_name']) ? mysqli_real_escape_string($db, $_POST['institution_name']) : null;

    // Check if the entry already exists before inserting
    $checkQuery = "SELECT * FROM attendance_students WHERE student_name = '$student_name' AND institution = '$institution_name'";
    $checkResult = mysqli_query($db, $checkQuery);

    if (mysqli_num_rows($checkResult) == 0) {
        // Entry does not exist, proceed with insertion
        $query = "INSERT INTO attendance_students (student_name, institution) VALUES ('$student_name', " . ($institution_name ? "'$institution_name'" : 'NULL') . ")";
        $execQuery = mysqli_query($db, $query) or die(mysqli_error($db));

        echo "Student has been added successfully!";
    } else {
        echo "Student already exists in the database.";
    }

    // Redirect to a new page to avoid form resubmission
    header("Location: addingStudents.php");
    exit();
}
?>
