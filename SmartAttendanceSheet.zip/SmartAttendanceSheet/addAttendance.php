<?php
# If session is not active, start the session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

# Explicitly set the timezone
date_default_timezone_set("Asia/Karachi"); // Adjust the timezone according to your location.

# If the user is not logged in, redirect them to the login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== TRUE) {
    echo "<script>" . "window.location.href='./login.php';" . "</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .container {
            margin-top: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid #dee2e6;
            padding: 8px;
            text-align: center;
        }

        th {
            background-color: #007bff;
            color: #fff;
        }

        input[type="text"] {
            width: 100%;
            padding: 8px;
            margin-top: 8px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #28a745;
            color: #fff;
            border: none;
            cursor: pointer;
        }
    </style>
</head>

<body>

    <div class="container">
        <form method="POST">
            <table border="1" cellspacing="0">
                <tr>
                    <th>Student Name</th>
                    <th>Present</th>
                    <th>Absent</th>
                    <th>Leave</th>
                    <th>Hospital / Medical</th>
                </tr>
                <?php
                require_once("config.php");

                // Check if the user is logged in
                if (isset($_SESSION['username'])) {
                    // Get the username of the logged-in user
                    $loggedInUsername = $_SESSION['username'];

                    // Fetch the institution of the logged-in user from the "users" table
                    $userQuery = "SELECT institution FROM users WHERE username = '$loggedInUsername'";
                    $userResult = mysqli_query($db, $userQuery);

                    if ($userResult && mysqli_num_rows($userResult) > 0) {
                        $userData = mysqli_fetch_assoc($userResult);
                        $userInstitution = $userData['institution'];

                        // Fetch students based on the institution
                        $fetchingStudents = mysqli_query($db, "SELECT * FROM attendance_students WHERE institution = '$userInstitution'") OR die(mysqli_error($db));

                        while ($data = mysqli_fetch_assoc($fetchingStudents)) {
                            $student_name = $data['student_name'];
                            $student_id = $data['id'];
                            ?>
                            <tr>
                                <td><?php echo $student_name; ?></td>
                                <td> <input type="checkbox" name="studentPresent[]" value="<?php echo $student_id; ?>" /></td>
                                <td> <input type="checkbox" name="studentAbsent[]" value="<?php echo $student_id; ?>" /></td>
                                <td> <input type="checkbox" name="studentLeave[]" value="<?php echo $student_id; ?>" /></td>
                                <td> <input type="checkbox" name="studentHoliday[]" value="<?php echo $student_id; ?>" /></td>
                            </tr>
                            <?php
                        }
                    } else {
                        echo "Error fetching user information: " . mysqli_error($db);
                    }
                } else {
                    echo "User not logged in.";
                }
                ?>
                <tr>
                    <td>Select Date (Optional)</td>
                    <td colspan="4">
                        <input type="text" name="selected_date" value="<?php echo isset($_POST['selected_date']) ? date('d F Y', strtotime($_POST['selected_date'])) : date('d F Y'); ?>" readonly />
                    </td>
                </tr>

                <tr>
                    <td colspan="5">
                        <input type="submit" name="addAttendanceBTN" class="btn btn-primary" value="Add Attendance" /> <br><br><br><br>
                        <a href="index.php" class="btn btn-secondary">Back</a>
                    </td>
                </tr>
            </table>
        </form>

        <?php
        if (isset($_POST['addAttendanceBTN'])) {
            // Date Logic Starts
            if ($_POST['selected_date'] == NULL) {
                $selected_date = date("Y-m-d");
            } else {
                $selected_date = date("Y-m-d", strtotime($_POST['selected_date']));
            }
            // Date Logic Ends

            // Check if attendance already exists for the selected date and for the logged-in user's institution
            $existingAttendanceQuery = "SELECT * FROM attendance WHERE curr_date = '$selected_date' AND student_id IN (SELECT id FROM attendance_students WHERE institution = '$userInstitution')";
            $existingAttendanceResult = mysqli_query($db, $existingAttendanceQuery);

            if ($existingAttendanceResult && mysqli_num_rows($existingAttendanceResult) > 0) {
                echo "<div class='alert alert-danger'>Attendance already added for the selected date.</div>";
            } else {
                $attendance_month = date("M", strtotime($selected_date));
                $attendance_year = date("Y", strtotime($selected_date));

                // Disable the input fields to prevent modification after adding attendance
                echo "<script>document.getElementsByName('studentPresent[]').forEach(item => item.disabled = true);</script>";
                echo "<script>document.getElementsByName('studentAbsent[]').forEach(item => item.disabled = true);</script>";
                echo "<script>document.getElementsByName('studentLeave[]').forEach(item => item.disabled = true);</script>";
                echo "<script>document.getElementsByName('studentHoliday[]').forEach(item => item.disabled = true);</script>";

                if (isset($_POST['studentPresent'])) {
                    $studentPresent = $_POST['studentPresent'];
                    $attendance = "P";

                    foreach ($studentPresent as $atd) {
                        mysqli_query($db, "INSERT INTO attendance(student_id, curr_date, attendance_month, attendance_year, attendance) VALUES('" . $atd . "', '" . $selected_date . "', '" . $attendance_month . "', '" . $attendance_year . "', '" . $attendance . "')") or die(mysqli_error($db));
                    }
                }

                if (isset($_POST['studentAbsent'])) {
                    $studentAbsent = $_POST['studentAbsent'];
                    $attendance = "A";

                    foreach ($studentAbsent as $atd) {
                        mysqli_query($db, "INSERT INTO attendance(student_id, curr_date, attendance_month, attendance_year, attendance) VALUES('" . $atd . "', '" . $selected_date . "', '" . $attendance_month . "', '" . $attendance_year . "', '" . $attendance . "')") or die(mysqli_error($db));
                    }
                }

                if (isset($_POST['studentLeave'])) {
                    $studentLeave = $_POST['studentLeave'];
                    $attendance = "L";

                    foreach ($studentLeave as $atd) {
                        mysqli_query($db, "INSERT INTO attendance(student_id, curr_date, attendance_month, attendance_year, attendance) VALUES('" . $atd . "', '" . $selected_date . "', '" . $attendance_month . "', '" . $attendance_year . "', '" . $attendance . "')") or die(mysqli_error($db));
                    }
                }

                if (isset($_POST['studentHoliday'])) {
                    $studentHoliday = $_POST['studentHoliday'];
                    $attendance = "H";

                    foreach ($studentHoliday as $atd) {
                        mysqli_query($db, "INSERT INTO attendance(student_id, curr_date, attendance_month, attendance_year, attendance) VALUES('" . $atd . "', '" . $selected_date . "', '" . $attendance_month . "', '" . $attendance_year . "', '" . $attendance . "')") or die(mysqli_error($db));
                    }
                }

                echo "<div class='alert alert-success'>Attendance added successfully</div>";
            }
        }
        ?>
    </div>

</body>

</html>
